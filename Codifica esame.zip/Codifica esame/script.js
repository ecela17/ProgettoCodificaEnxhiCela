// Funzione per gestire l'evidenziazione dei fenomeni
function togglePhenomenonHighlight(phenomenon) {
    const elements = document.querySelectorAll(`.${phenomenon}`);
    elements.forEach(el => {
        el.classList.toggle('highlight');
    });
}

// Funzione per gestire il click sulle aree dell'immagine
function handleImageAreaClick(e) {
    e.preventDefault();
    const targetId = e.target.getAttribute('href').substring(1);
    const targetElement = document.getElementById(targetId);

    if (targetElement) {
        // Rimuovi l'evidenziazione precedente
        const previousHighlight = document.querySelector('.current-highlight');
        if (previousHighlight) {
            previousHighlight.classList.remove('current-highlight');
        }

        // Aggiungi la nuova evidenziazione
        targetElement.classList.add('current-highlight');

        // Scorri alla riga evidenziata
        targetElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
}

function toggleAbbreviations() {
    const abbrElements = document.querySelectorAll('.abbr');
    const expanElements = document.querySelectorAll('.expan');
    const toggleButton = document.getElementById('toggle-abbr');

    if (abbrElements[0].style.display === 'none') {
        abbrElements.forEach(el => el.style.display = 'inline');
        expanElements.forEach(el => el.style.display = 'none');
        toggleButton.textContent = 'Mostra forme espanse';
    } else {
        abbrElements.forEach(el => el.style.display = 'none');
        expanElements.forEach(el => el.style.display = 'inline');
        toggleButton.textContent = 'Mostra abbreviazioni';
    }
}

// Funzione per ricalcolare le coordinate delle aree immagine
function recalculateImageMapCoordinates() {
    const imageMaps = document.querySelectorAll('img[usemap]');

    imageMaps.forEach(img => {
        const mapName = img.getAttribute('usemap').substring(1);
        const map = document.querySelector(`map[name="${mapName}"]`);
        const originalWidth = img.naturalWidth;
        const currentWidth = img.width;

        if (originalWidth && currentWidth) {
            const scale = currentWidth / originalWidth;
            const areas = map.querySelectorAll('area');

            areas.forEach(area => {
                const originalCoords = area.dataset.coords.split(',').map(Number);
                const scaledCoords = originalCoords.map(coord => coord * scale);
                area.coords = scaledCoords.join(',');
            });
        }
    });
}

// Funzione di inizializzazione
function init() {
    // Gestione dei pulsanti dei fenomeni
    const phenomenonButtons = document.querySelectorAll('.phenomenon-btn');
    phenomenonButtons.forEach(button => {
        button.addEventListener('click', () => {
            const phenomenon = button.getAttribute('data-phenomenon');
            togglePhenomenonHighlight(phenomenon);
            button.classList.toggle('active');
        });
    });

    const toggleAbbrButton = document.getElementById('toggle-abbr');
    if (toggleAbbrButton) {
        toggleAbbrButton.addEventListener('click', toggleAbbreviations);
    }

    // Gestione del click sulle aree dell'immagine
    const imageAreas = document.querySelectorAll('area');
    imageAreas.forEach(area => {
        area.addEventListener('click', handleImageAreaClick);
    });

    // Aggiungi la funzionalità di zoom alle immagini del facsimile
    const facsimileImages = document.querySelectorAll('.facsimile-image');
    facsimileImages.forEach(img => {
        img.addEventListener('click', function (e) {
            const rect = this.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;

            this.style.transformOrigin = `${x}px ${y}px`;
            this.classList.toggle('zoomed');
        });
    });

    // Ricalcola le coordinate delle aree immagine al caricamento iniziale
    recalculateImageMapCoordinates();

    // Ricalcola le coordinate delle aree immagine al resize della finestra
    window.addEventListener('resize', recalculateImageMapCoordinates);
}

// Esegui l'inizializzazione quando il DOM è completamente caricato
document.addEventListener('DOMContentLoaded', init);
